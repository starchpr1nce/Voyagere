//
//  InfoViewModel.swift
//  Voyager
//
//  Created by admin on 20.11.2023.
//

import Combine

final class InfoViewModel: ObservableObject {
    
}
