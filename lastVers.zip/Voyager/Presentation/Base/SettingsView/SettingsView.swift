//
//  SettingsView.swift
//  Voyager
//
//  Created by admin on 20.11.2023.
//

import SwiftUI
import UIPilot

struct SettingsView: View {
    @EnvironmentObject var settinsViewModel: SettingsViewModel
    @EnvironmentObject var pilot: UIPilot<String>
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

//#Preview {
//    SettingsView()
//}
