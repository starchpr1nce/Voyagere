//
//  ApplicationController.swift
//  Voyager
//
//  Created by admin on 20.11.2023.
//

import SwiftUI

final class ApplicationController: ObservableObject {
//    
//    @Published private(set) var currentRoute: String = PilotStringRoutes.gameWheelComplicated.value
//    @Published private(set) var currentStage: AppControllerStageState
//    
//    
//    init() {
//        self.currentStage = .getStage()
//    }
//    


}

