//
//  SportBettingView.swift
//  SPR
//
//  Created by admin on 11/22/23.
//

import SwiftUI

struct SportBettingView: View {
    
    @EnvironmentObject var sportBettingViewModel: SportBettingViewModel
    
    @State private var hideSizeBetBar = true
    
    var body: some View {

        GeometryReader { geo in
            VStack {
                switch sportBettingViewModel._gameStatus {
                case .chooseBet:
                    chooseBetView(size: geo.size)
                case .animation:
                    animationView(size: geo.size)
                case .result:
                    resultView(size: geo.size)
                }
            }
        }
        
    }
    
    @ViewBuilder private func chooseBetButtonView(_ rate: Double) -> some View {
        Button(action: {
            sportBettingViewModel.playerRate = rate
            if hideSizeBetBar {
                hideSizeBetBar.toggle()
            }
        }, label: {
            Text("W1: \(rate, specifier: "%.1f")")
        })   .padding(.leading, 22)
        
    }
    
    @ViewBuilder private func chooseSizeBetButtonView(_ index: Int) -> some View {
        Button(action: {
            sportBettingViewModel.playerBetSize = sportBettingViewModel.sizeBet[index]
        }, label: {
            Text("\(sportBettingViewModel.sizeBet[index])")
        })
    }
    
    @ViewBuilder private func chooseBetView(size: CGSize) -> some View {
        VStack {
            Text("Choose your Bet")
            
            VStack {
                VStack {
                    Text("Match Date: \(Date(), style:  .date)")
                    Text("Match Time: \(Date.now.addingTimeInterval(600) + 1200, style: .time)")
                    
                    HStack {
                        Text("Team 1")
                            .padding(.leading, 22)
                        Spacer()
                        Text("Team 2")
                            .padding(.trailing, 22)
                    }
                    
                    HStack {
                        chooseBetButtonView( sportBettingViewModel.winRate[0]).padding(.leading, 22)
                        
                        Spacer()
                        
                        chooseBetButtonView( sportBettingViewModel.drawRate[0])
                        
                        Spacer()

                        chooseBetButtonView( sportBettingViewModel.winRate[1]).padding(.trailing, 22)
                    }
                    
                }
            }
            
            if !hideSizeBetBar {
                VStack {
                    Spacer()
                    HStack {

                        ForEach(0..<3) { index in
                            chooseSizeBetButtonView(index)
                        }
                        
                    }
            
                    Text("Potential Win: \((sportBettingViewModel.playerRate * Double(sportBettingViewModel.playerBetSize)), specifier: "%.f")")
                    
                    Button(action: {
                        sportBettingViewModel.setAnimation()
                    }, label: {
                        Text("Lets Bet")
                    })
                }
            }
            
        } .frame(width: size.width, height: size.height)
    }
        
    @ViewBuilder private func animationView(size: CGSize) -> some View {
        
        VStack {
            HStack {
                Image("field")
                    .resizable()
                    .scaledToFit()
                
                AnimatedBallView()
            }

        } .frame(width: size.width, height: size.height)
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 3)  {
                    sportBettingViewModel.setResult()
                }
            }
    }

    

    @ViewBuilder private func resultView(size: CGSize) -> some View {
        let isWin = sportBettingViewModel.determineWin()
        
         VStack {
            Text(isWin ? "Вы выиграли!" : "Вы проиграли!")
        
        } .frame(width: size.width, height: size.height)
    }
}


struct AnimatedBallView: View {
    @State private var move = false
    var body: some View {
        Image("ball")
            .resizable()
            .frame(width: 60, height: 60)
            .offset(x: move ? -50 : -300)
            .animation(
                Animation.easeInOut(duration: 1)
                    .repeatForever(autoreverses: true)
                    .speed(0.5)
            )
            .onAppear{
                self.move.toggle()}
    }
}

#Preview {
    SportBettingView().environmentObject(SportBettingViewModel())
}
