
import SwiftUI



struct SRPView: View {

    @EnvironmentObject var sprViewModel: SPRViewModel
    
    
    let myChoise = ["myP", "myR", "myS"]
    let enemyChoise = ["enP", "enR", "enS"]
    
    var body: some View {
//        GeometryReader {geo in

            
            VStack{
                switch sprViewModel._gameStatus {
                case .initial:
                    initialView(/*size: geo.size*/)
                case .animating:
//                    animatingView(size: geo.size)
                    initialView(/*size: geo.size*/)
                case .result:
//                    resultView(size: geo.size)
                    initialView(/*size: geo.size*/)
                case .endGame:
//                    endGameView(size: geo.size)
                    initialView(/*size: geo.size*/)
                }
            }
//        }

    }
    

    
    func initialView(/*size: CGSize*/) -> some View {
        ZStack {
    
//            Color.init(uiColor: .black).ignoresSafeArea(.all,  edges: .all)
            Image("sprback")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea(.all)
            
            Image("students")
            
            
            VStack {
                //Enemy Half
                Spacer()
                VStack  {
                    HStack {
                        Image(myChoise.randomElement() ?? "myR")
                            .frame(width: 40, height: 40)
                            .padding(.leading, 32)
                        
                        Spacer()
                        
                        Image(enemyChoise.randomElement() ?? "enP")
                            .frame(width: 40, height: 40)
                            .padding(.trailing, 32)
                        
                    }
                       
                    
                } .padding(.bottom, 60)
                
                //PlayerHalf
                VStack {
                    Text("Чем играешь?")
                        .foregroundColor(.white)
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: 280)
                        .background(Color.indigo.opacity(1))
                        .border(Color.black, width: 2)
                    
                    VStack {
//                        ForEach(SPRViewModel.Choices.allCases, id: \.self) { choice in
//                            Button {
//                                sprViewModel.round += 1
//                                
//                                let index = Int.random(in: 0...SPRViewModel.Choices.allCases.count-1)
//                                sprViewModel.computerChoice = SPRViewModel.Choices.allCases[index]
//                                sprViewModel.showComputerChoice = true
//                                sprViewModel.checkWin(playerChoice: choice)
//                                sprViewModel.playerChoice = choice
//                                sprViewModel.setAnimating()
//                            } label: {
//                                Image(choice.rawValue)
//                                    .resizable()
//                                    .frame(width: 40, height: 40)
//                            }
//                            .font(.system(size: 60))
//                        }
                        
                        Button(action: {
                            playGame(with: .rock)
                        }, label: {
                            Text("Камень")
                                .foregroundColor(.white)
                                .font(.headline)
                                .padding()
                                .frame(maxWidth: 280)
                                .background(Color.orange.opacity(1))
                                .border(Color.black, width: 2)
                        })
                        
                        Button(action: {
                            playGame(with: .scissors)
                        }, label: {
                            Text("Ножницы")
                                .foregroundColor(.white)
                                .font(.headline)
                                .padding()
                                .frame(maxWidth: 280)
                                .background(Color.orange.opacity(1))
                                .border(Color.black, width: 2)
                        })
                        
                        Button(action: {
                            playGame(with: .paper)
                        }, label: {
                            Text("Бумага")
                                .foregroundColor(.white)
                                .font(.headline)
                                .padding()
                                .frame(maxWidth: 280)
                                .background(Color.orange.opacity(1))
                                .border(Color.black, width: 2)
                        })
                        
                    }
                    
                    .padding(.bottom, 60)
                }
                
            }
        }
    }
    
    func playGame(with choice: SPRViewModel.MyChoices) {
        sprViewModel.playerChoice = choice
        sprViewModel.computerChoice = SPRViewModel.EnemyChoices.allCases.randomElement() ?? .scissors
        sprViewModel.checkWin(playerChoice: choice)
        sprViewModel.setAnimating()
    }
    
    func animatingView(size: CGSize) -> some View {
        ZStack {
    
//            Color.init(uiColor: .black).ignoresSafeArea(.all,  edges: .all)
            Image("sprback")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea(.all)
            
            Image("students")
            
        HStack {
            AnimatedMyRockView()
            Spacer()
            AnimatedEnemyRockView()
        }
        .frame(width: size.width, height: size.height / 2)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                if sprViewModel.loses == 3 || sprViewModel.wins == 3  {
                    sprViewModel.setEndGame()
                } else {
                    sprViewModel.setResult()
                }
            }
        }
    }
    }
    
    struct AnimatedMyRockView: View {
        @State private var moveUp = false
        
        var body: some View {

            Image("myR")
                .resizable()
                .frame(width: 100, height: 100)
                .offset(y: moveUp ? -100 : 100)
                .animation(
                    Animation.easeInOut(duration: 1)
                        .repeatForever(autoreverses: true)
                        .speed(6.0)
                )
                .onAppear {
                    self.moveUp.toggle()
                }
        }
    }
    
    struct AnimatedEnemyRockView: View {
        @State private var moveUp = false
        
        var body: some View {

            Image("enR")
                .resizable()
                .frame(width: 100, height: 100)
                .offset(y: moveUp ? -100 : 100)
                .animation(
                    Animation.easeInOut(duration: 1)
                        .repeatForever(autoreverses: true)
                        .speed(6.0)
                )
                .onAppear {
                    self.moveUp.toggle()
                }
        }
    }
    
    
    func resultView(size: CGSize) -> some View {
        ZStack {
    
            Image("sprback")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea(.all)
            
            Image("students")
            
        VStack {

            Spacer()
            HStack {
                Image(sprViewModel.playerChoice?.rawValue ?? "")
                    .resizable()
                    .frame(width: 100, height: 100)
                
                Spacer()
                
                Image(sprViewModel.computerChoice.rawValue)
                    .resizable()
                    .frame(width: 100, height: 100)
            }
            Spacer()
            
            HStack {
                Spacer()
                Text(sprViewModel.gameOutcome)
                    .foregroundColor(.white)
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: 280)
                    .background(Color.indigo.opacity(1))
                    .border(Color.black, width: 2)
                Spacer()
            } .padding(.bottom, 16)
            
            HStack {
                Text("Победы: \(sprViewModel.wins)")
                    .padding(.leading, 22)
                    .foregroundColor(.white)
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: 280)
                    .background(Color.mint.opacity(1))
                    .border(Color.black, width: 2)
                Spacer()
                Text("Поражения: \(sprViewModel.loses)")
                    .foregroundColor(.white)
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: 280)
                    .background(Color.mint.opacity(1))
                    .border(Color.black, width: 2)
                    .padding(.trailing, 22)
                
            } .padding(.bottom, 16)
            


            Button(action: {
                sprViewModel.setInitial()
            }, label: {
                Text("Ещё разок")
                    .foregroundColor(.white)
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: 280)
                    .background(Color.orange.opacity(1))
                    .border(Color.black, width: 2)
            })

        } .padding()
    }
    }
    
    func endGameView(size: CGSize) -> some View {

            VStack {
                if sprViewModel.loses == 3 {
                    Text("You lose")
                } else if sprViewModel.wins == 3 {
                    Text("You Win")
                }
                
                Button {
                    
                } label: {
                    Text("Play Again")
                }
                
                Button {
                    
                } label: {
                    Text("Next")
                }

            }
        
    }
    
    
}

#Preview {
    SRPView().environmentObject(SPRViewModel())
}
